Wavely — cloud build package for Codemagic

This package contains:
- Wavely.zip: the original Android project archive
- codemagic.yaml: a Codemagic workflow that extracts the archive, downloads Gradle 8.7, and builds a debug APK

PHONE-ONLY SETUP
1. Extract this package on your Android phone using your file manager or an archive app.
2. On GitHub, create a new empty repository (do not add a README or .gitignore at creation).
3. Open the repository in your browser and choose Add file -> Upload files.
4. Upload Wavely.zip and codemagic.yaml as two separate files in the repository root. Do not upload only this outer package ZIP.
5. Open https://codemagic.io/ and sign in using GitHub.
6. Add an application, connect the repository, choose the repository and the native Android project type if prompted.
7. Ensure the repository's default branch contains codemagic.yaml, then start a build using the workflow “Wavely Android APK (debug)”.
8. When the build finishes successfully, download app-debug.apk from the build's Artifacts section.

NOTES
- This creates a debug APK for testing, not a Play Store release.
- The app can compile without a Jamendo client ID, but the Jamendo music catalog may not work until you provide a valid JAMENDO_CLIENT_ID as a Codemagic environment variable named JAMENDO_CLIENT_ID.
- Never put API keys, passwords, or signing keystores in a public GitHub repository.
- The cloud build can still fail if the source has Kotlin/Gradle errors; check the build log if that happens.
